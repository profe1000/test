//
//  ViewController.swift
//  app9 multiscreen 3
//
//  Created by MacBook Pro on 10/24/18.
//  Copyright © 2018 MacBook Pro. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
     var nametext=""
    
    @IBOutlet weak var textfield: UITextField!
    
    @IBAction func btnnavscreen2(_ sender: Any) {
        print("Navigate")
        self.nametext = textfield.text!
        performSegue(withIdentifier: "name", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var vc = segue.destination as! screentwo
        vc.finalname=self.nametext
    }


}

